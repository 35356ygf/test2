package com.example.test2;

import java.sql.Date;

public class Expense {
    private int expenseid;
    private String expensetype;
    private double amount;
    private Date date;

    public Expense(int expenseid, String expensetype, double amount, Date date) {
        this.expenseid = expenseid;
        this.expensetype = expensetype;
        this.amount = amount;
        this.date = date;
    }

    public int getExpenseid() {
        return expenseid;
    }

    public void setExpenseid(int expenseid) {
        this.expenseid = expenseid;
    }

    public String getExpensetype() {
        return expensetype;
    }

    public void setExpensetype(String expensetype) {
        this.expensetype = expensetype;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
