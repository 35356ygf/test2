package com.example.test2;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class HelloController implements Initializable {

    @FXML
    private Label welcomeText;

    @FXML
    private TextField id;
    @FXML
    private TextField username;
    @FXML
    private TextField email;
    @FXML
    private TextField password;

    @FXML
    private TableView<Expense> expense_tracker;
    @FXML
    private TableColumn<Expense, Integer> expenseid;
    @FXML
    private TableColumn<Expense, String> expensetype;
    @FXML
    private TableColumn<Expense, Double> amount;
    @FXML
    private TableColumn<Expense, Date> date;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        initializeExpenseTrackerTable();
    }

    private void initializeExpenseTrackerTable() {
        expenseid.setCellValueFactory(new PropertyValueFactory<>("expenseId"));
        expensetype.setCellValueFactory(new PropertyValueFactory<>("expenseType"));
        amount.setCellValueFactory(new PropertyValueFactory<>("amount"));
        date.setCellValueFactory(new PropertyValueFactory<>("date"));
        fetchData();
    }

    @FXML
    protected void onHelloButtonClick(ActionEvent event) {
        fetchData();
    }

    private void fetchData() {
        ObservableList<Expense> list = FXCollections.observableArrayList();

        String jdbcUrl = "jdbc:mysql://localhost:3306/test2";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "SELECT * FROM expense_tracker";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                int expenseId = resultSet.getInt("expenseid");
                String expenseType = resultSet.getString("expensetype");
                double amount = resultSet.getDouble("amount");
                Date date = resultSet.getDate("date");
                list.add(new Expense(expenseId, expenseType, amount, date));
            }

            expense_tracker.setItems(list);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void InsertData(ActionEvent actionEvent) {
        String u_name = username.getText();
        String u_email = email.getText();
        String u_password = password.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/test2";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "INSERT INTO expense_tracker (expensetype, amount, date) VALUES (?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, u_name);
            preparedStatement.setDouble(2, Double.parseDouble(u_email));
            preparedStatement.setDate(3, Date.valueOf(u_password));
            preparedStatement.executeUpdate();
            fetchData();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void UpdateData(ActionEvent actionEvent) {
        String user_id = id.getText();
        String u_name = username.getText();
        String u_email = email.getText();
        String u_password = password.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/test2";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "UPDATE expense_tracker SET expensetype = ?, amount = ?, date = ? WHERE expenseid = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, u_name);
            preparedStatement.setDouble(2, Double.parseDouble(u_email));
            preparedStatement.setDate(3, Date.valueOf(u_password));
            preparedStatement.setInt(4, Integer.parseInt(user_id));
            preparedStatement.executeUpdate();
            fetchData();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void DeleteData(ActionEvent actionEvent) {
        String user_id = id.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/test2";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "DELETE FROM expense_tracker WHERE expenseid = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, Integer.parseInt(user_id));
            preparedStatement.executeUpdate();
            fetchData();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void LoadData(ActionEvent actionEvent) {
        String user_id = id.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/test2";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "SELECT * FROM expense_tracker WHERE expenseid = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, Integer.parseInt(user_id));
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                String u_name = resultSet.getString("expensetype");
                String u_email = resultSet.getString("amount");
                String u_password = resultSet.getString("date");

                username.setText(u_name);
                email.setText(u_email);
                password.setText(u_password);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
